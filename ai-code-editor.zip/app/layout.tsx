import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Script from "next/script"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "AI Code Editor for Students",
  description: "An AI-powered code editor designed to help students learn programming",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Script
          src="https://unpkg.com/monaco-editor@0.44.0/min/vs/loader.js"
          strategy="beforeInteractive"
          onLoad={() => {
            // Configure Monaco Editor
            if (typeof window !== "undefined" && (window as any).require) {
              ;(window as any).require.config({
                paths: { vs: "https://unpkg.com/monaco-editor@0.44.0/min/vs" },
              })
            }
          }}
        />
        {children}
      </body>
    </html>
  )
}
