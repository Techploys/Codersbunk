"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Code, MessageSquare, Play, Lightbulb, Loader2 } from "lucide-react"
import dynamic from "next/dynamic"
import AIChat from "@/components/ai-chat"
import CodeRunner from "@/components/code-runner"
import { analyzeCode } from "@/lib/ai-actions"

// Dynamically import CodeEditor to avoid SSR issues
const CodeEditor = dynamic(() => import("@/components/code-editor"), {
  ssr: false,
  loading: () => (
    <div className="h-full w-full flex items-center justify-center bg-gray-50 rounded-lg">
      <div className="flex items-center gap-2 text-gray-600">
        <Loader2 className="h-5 w-5 animate-spin" />
        Loading editor...
      </div>
    </div>
  ),
})

const SAMPLE_CODE = {
  javascript: `// Welcome to your AI Code Editor!
// Try writing some JavaScript code here

function greetStudent(name) {
    return "Hello, " + name + "! Ready to learn?";
}

console.log(greetStudent("Student"));

// Ask the AI tutor for help with your code!`,

  python: `# Welcome to your AI Code Editor!
# Try writing some Python code here

def greet_student(name):
    return f"Hello, {name}! Ready to learn?"

print(greet_student("Student"))

# Ask the AI tutor for help with your code!`,

  java: `// Welcome to your AI Code Editor!
// Try writing some Java code here

public class HelloStudent {
    public static void main(String[] args) {
        System.out.println("Hello, Student! Ready to learn?");
    }
}

// Ask the AI tutor for help with your code!`,
}

export default function CodeEditorPage() {
  const [code, setCode] = useState(SAMPLE_CODE.javascript)
  const [language, setLanguage] = useState("javascript")
  const [analysis, setAnalysis] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [isEditorReady, setIsEditorReady] = useState(false)

  useEffect(() => {
    // Add a small delay to ensure Monaco is loaded
    const timer = setTimeout(() => {
      setIsEditorReady(true)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const handleLanguageChange = (newLanguage: string) => {
    setLanguage(newLanguage)
    setCode(SAMPLE_CODE[newLanguage as keyof typeof SAMPLE_CODE] || "")
  }

  const handleAnalyzeCode = async () => {
    if (!code.trim()) return

    setIsAnalyzing(true)
    try {
      const result = await analyzeCode(code, language)
      setAnalysis(result.analysis)
    } catch (error) {
      setAnalysis("Unable to analyze code at the moment.")
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Code Editor for Students</h1>
          <p className="text-gray-600">Write code, get AI assistance, and learn programming concepts!</p>
        </div>

        {/* Language Selector */}
        <div className="mb-4">
          <Select value={language} onValueChange={handleLanguageChange}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="javascript">JavaScript</SelectItem>
              <SelectItem value="python">Python</SelectItem>
              <SelectItem value="java">Java</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Main Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
          {/* Code Editor */}
          <div className="lg:col-span-2">
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5" />
                  Code Editor
                </CardTitle>
              </CardHeader>
              <CardContent className="h-[calc(100%-80px)]">
                {isEditorReady ? (
                  <CodeEditor value={code} onChange={setCode} language={language} />
                ) : (
                  <div className="h-full w-full flex items-center justify-center bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 text-gray-600">
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Initializing editor...
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Panel */}
          <div className="space-y-6">
            <Tabs defaultValue="chat" className="h-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="chat" className="flex items-center gap-1">
                  <MessageSquare className="h-4 w-4" />
                  AI Tutor
                </TabsTrigger>
                <TabsTrigger value="run" className="flex items-center gap-1">
                  <Play className="h-4 w-4" />
                  Run
                </TabsTrigger>
                <TabsTrigger value="analyze" className="flex items-center gap-1">
                  <Lightbulb className="h-4 w-4" />
                  Analyze
                </TabsTrigger>
              </TabsList>

              <TabsContent value="chat" className="h-[calc(100%-50px)]">
                <AIChat code={code} language={language} />
              </TabsContent>

              <TabsContent value="run" className="h-[calc(100%-50px)]">
                <CodeRunner code={code} language={language} />
              </TabsContent>

              <TabsContent value="analyze" className="h-[calc(100%-50px)]">
                <Card className="h-full flex flex-col">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>Code Analysis</span>
                      <Button onClick={handleAnalyzeCode} disabled={isAnalyzing || !code.trim()} size="sm">
                        {isAnalyzing ? "Analyzing..." : "Analyze Code"}
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <div className="h-full bg-gray-50 p-3 rounded-lg overflow-auto">
                      {analysis ? (
                        <pre className="text-sm whitespace-pre-wrap">{analysis}</pre>
                      ) : (
                        <p className="text-gray-500 text-sm">
                          Click "Analyze Code" to get AI feedback on your code quality, potential issues, and
                          suggestions for improvement.
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
