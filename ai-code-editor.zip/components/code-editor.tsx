"use client"

import { useEffect, useRef, useCallback } from "react"
import * as monaco from "monaco-editor"

interface CodeEditorProps {
  value: string
  onChange: (value: string) => void
  language: string
  theme?: string
}

export default function CodeEditor({ value, onChange, language, theme = "vs-dark" }: CodeEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null)
  const monacoRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null)
  const resizeObserverRef = useRef<ResizeObserver | null>(null)

  // Suppress ResizeObserver errors
  useEffect(() => {
    const originalError = console.error
    console.error = (...args) => {
      if (
        typeof args[0] === "string" &&
        args[0].includes("ResizeObserver loop completed with undelivered notifications")
      ) {
        return
      }
      originalError(...args)
    }

    return () => {
      console.error = originalError
    }
  }, [])

  const handleResize = useCallback(() => {
    if (monacoRef.current) {
      monacoRef.current.layout()
    }
  }, [])

  useEffect(() => {
    if (editorRef.current && !monacoRef.current) {
      // Initialize Monaco Editor
      monacoRef.current = monaco.editor.create(editorRef.current, {
        value,
        language,
        theme,
        fontSize: 14,
        minimap: { enabled: false },
        scrollBeyondLastLine: false,
        automaticLayout: false, // We'll handle layout manually
        tabSize: 2,
        insertSpaces: true,
        wordWrap: "on",
        lineNumbers: "on",
        glyphMargin: true,
        folding: true,
        lineDecorationsWidth: 10,
        lineNumbersMinChars: 3,
      })

      // Listen for content changes
      monacoRef.current.onDidChangeModelContent(() => {
        const currentValue = monacoRef.current?.getValue() || ""
        onChange(currentValue)
      })

      // Set up ResizeObserver with error handling
      if (editorRef.current) {
        try {
          resizeObserverRef.current = new ResizeObserver(() => {
            // Debounce the resize to prevent the loop error
            setTimeout(handleResize, 0)
          })
          resizeObserverRef.current.observe(editorRef.current)
        } catch (error) {
          // Fallback to window resize if ResizeObserver fails
          window.addEventListener("resize", handleResize)
        }
      }

      // Initial layout
      setTimeout(() => {
        handleResize()
      }, 100)
    }

    return () => {
      if (resizeObserverRef.current) {
        resizeObserverRef.current.disconnect()
      }
      window.removeEventListener("resize", handleResize)
      if (monacoRef.current) {
        monacoRef.current.dispose()
        monacoRef.current = null
      }
    }
  }, [])

  useEffect(() => {
    if (monacoRef.current && monacoRef.current.getValue() !== value) {
      const position = monacoRef.current.getPosition()
      monacoRef.current.setValue(value)
      if (position) {
        monacoRef.current.setPosition(position)
      }
    }
  }, [value])

  useEffect(() => {
    if (monacoRef.current) {
      const model = monacoRef.current.getModel()
      if (model) {
        monaco.editor.setModelLanguage(model, language)
      }
    }
  }, [language])

  return <div ref={editorRef} className="h-full w-full" style={{ minHeight: "400px" }} />
}
