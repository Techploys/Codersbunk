"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Play, Square, AlertCircle } from "lucide-react"

interface CodeRunnerProps {
  code: string
  language: string
}

export default function CodeRunner({ code, language }: CodeRunnerProps) {
  const [output, setOutput] = useState("")
  const [isRunning, setIsRunning] = useState(false)
  const [error, setError] = useState("")

  const runCode = async () => {
    setIsRunning(true)
    setOutput("")
    setError("")

    try {
      // Simulate code execution (in a real implementation, you'd send this to a backend service)
      if (language === "javascript") {
        // Simple JavaScript execution simulation
        const result = executeJavaScript(code)
        setOutput(result)
      } else if (language === "python") {
        // Python execution would require a backend service
        setOutput("Python execution requires a backend service. This is a demo output:\nHello, World!")
      } else {
        setOutput(`${language} execution is not yet supported in this demo.`)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsRunning(false)
    }
  }

  const executeJavaScript = (code: string): string => {
    try {
      // Create a safe execution environment
      const logs: string[] = []
      const originalConsoleLog = console.log

      // Override console.log to capture output
      console.log = (...args) => {
        logs.push(args.map((arg) => String(arg)).join(" "))
      }

      // Execute the code
      const func = new Function(code)
      const result = func()

      // Restore console.log
      console.log = originalConsoleLog

      let output = logs.join("\n")
      if (result !== undefined) {
        output += output ? "\n" + String(result) : String(result)
      }

      return output || "Code executed successfully (no output)"
    } catch (error) {
      throw new Error(`JavaScript Error: ${error instanceof Error ? error.message : "Unknown error"}`)
    }
  }

  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Output</span>
          <Button onClick={runCode} disabled={isRunning || !code.trim()} size="sm" className="flex items-center gap-2">
            {isRunning ? (
              <>
                <Square className="h-4 w-4" />
                Running...
              </>
            ) : (
              <>
                <Play className="h-4 w-4" />
                Run Code
              </>
            )}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1">
        <ScrollArea className="h-full">
          {error ? (
            <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
              <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-red-800">Error</p>
                <pre className="text-sm text-red-700 whitespace-pre-wrap mt-1">{error}</pre>
              </div>
            </div>
          ) : (
            <pre className="text-sm bg-gray-50 p-3 rounded-lg whitespace-pre-wrap min-h-[100px]">
              {output || 'Click "Run Code" to execute your code...'}
            </pre>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
