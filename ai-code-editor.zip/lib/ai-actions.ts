"use server"

import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function getCodeHelp(code: string, question: string, language: string) {
  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: `You are a helpful coding tutor for students. You help explain code, debug issues, suggest improvements, and teach programming concepts. Always be encouraging and educational in your responses. Focus on helping students learn and understand rather than just giving answers.`,
      prompt: `
        Language: ${language}
        Code: 
        \`\`\`${language}
        ${code}
        \`\`\`
        
        Student Question: ${question}
        
        Please provide a helpful, educational response that explains concepts clearly and encourages learning.
      `,
    })

    return { success: true, response: text }
  } catch (error) {
    return { success: false, response: "Sorry, I encountered an error. Please try again." }
  }
}

export async function analyzeCode(code: string, language: string) {
  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: `You are a code analysis tutor. Analyze the provided code and give constructive feedback including:
      1. Code quality and best practices
      2. Potential bugs or issues
      3. Suggestions for improvement
      4. Educational explanations of concepts used
      Be encouraging and focus on learning opportunities.`,
      prompt: `
        Please analyze this ${language} code:
        \`\`\`${language}
        ${code}
        \`\`\`
      `,
    })

    return { success: true, analysis: text }
  } catch (error) {
    return { success: false, analysis: "Unable to analyze code at the moment." }
  }
}
